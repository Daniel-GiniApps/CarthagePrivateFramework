//
//  PSPlayLinkSDK.h
//  PlayLinkSDKLibrary
//
//  Created by Arkadi Yoskovitz on 9/13/20.
//  Copyright © 2020 PlayStudios. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSPlayLinkSDK : NSObject
@property (class, nonatomic, readonly) PSPlayLinkSDK *sharedInstance NS_SWIFT_NAME(shared);
@property (nonatomic, readonly) NSString *someProperty;

- (void)changeSomePropertyToNewValue:(NSString *)newValue;
- (void)performAsynchronizeActionWithCompletionHandler:(void (^ __nullable)(BOOL finished))completion;

@end

NS_ASSUME_NONNULL_END
