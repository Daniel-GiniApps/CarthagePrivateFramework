//
//  PlayLinkSDKFramework.h
//  PlayLinkSDKFramework
//
//  Created by Arkadi Yoskovitz on 9/13/20.
//  Copyright © 2020 PlayStudios. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PlayLinkSDKFramework.
FOUNDATION_EXPORT double PlayLinkSDKFrameworkVersionNumber;

//! Project version string for PlayLinkSDKFramework.
FOUNDATION_EXPORT const unsigned char PlayLinkSDKFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PlayLinkSDKFramework/PublicHeader.h>

#import <PlayLinkSDKFramework/PSPlayLinkSDK.h>

